dotnet build Handout.csproj -o ./output
