﻿using System;
using System.IO;

namespace PresentationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ExpressionTree.ExpressionTree newTree = new ExpressionTree.ExpressionTree("4 + (8 + 6) * (8 + 9)");
                newTree.TreeRoot = ExpressionTree.ExpressionTreeExtension.CreatePostFixTree(newTree.PostFixExpression, newTree.Variables, newTree.VariableDict);
                double result = newTree.Evaluate();
            }
            catch(Exception ex)
            { 
                string exception = ex.ToString();
                File.WriteAllText("excption.txt", exception);
            }
        }
    }
}
